
/* Author: Lang Xu */
int timeout(struct Asteroids *single);

int split(struct Asteroids *single);

int exhaust(struct Asteroids *single);

int fission(struct Asteroids *single);

